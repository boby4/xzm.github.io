import {
  uploadUrl,
  baseUrl
} from '@/api/config'

// import { getStorage } from '@/utils/wx';
import {
  StorageKey
} from '@/utils/config'

export const getStorage = key => wx.getStorageSync(key)

export const setStorage = (key, value) => wx.setStorageSync(key, value)

export const getLocation = () =>
  new Promise(resolve => {
    wx.getLocation({
      success ({
        latitude,
        longitude,
        speed,
        accuracy
      }) {
        resolve({
          latitude,
          longitude,
          speed,
          accuracy
        })
      },
      fail () {
        resolve({
          latitude: -999,
          longitude: -999
        })
      }
    })
  })

export const chooseLocation = () =>
  new Promise((resolve, reject) => {
    wx.chooseLocation({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const openLocation = obj =>
  new Promise((resolve, reject) => {
    wx.openLocation(obj)
  })

export const removeStorage = key =>
  new Promise((resolve, reject) => {
    wx.removeStorage({
      key,
      success (res) {
        resolve(res.data)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const clearStorage = () =>
  new Promise((resolve, reject) => {
    try {
      wx.clearStorageSync()
      resolve()
    } catch (e) {
      reject(e)
    }
  })

export const wxLogin = () =>
  new Promise((resolve, reject) => {
    wx.login({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const chooseImage = ({
  count = 1,
  sizeType = ['original', 'compressed'],
  sourceType = ['album', 'camera']
}) =>
  new Promise((resolve, reject) => {
    wx.chooseImage({
      count: count,
      sizeType: sizeType,
      sourceType: sourceType,
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const showShareMenu = obj => {
  return wx.showShareMenu(obj)
}

export const hideShareMenu = obj => {
  wx.hideShareMenu(obj)
}

export const pageScrollTo = () => {
  return wx.pageScrollTo
}

// export const getUserInfo = obj =>
//   new Promise((resolve, reject) => {
//     wx.getUserInfo({
//       ...obj,
//       success (res) {
//         resolve(res)
//       },
//       fail (e) {
//         reject(e)
//       }
//     })
//   })

export const navigateTo = url => {
  wx.navigateTo({
    url
  })
}

export const redirectTo = url => {
  wx.redirectTo({
    url
  })
}

export const navigateBack = (delta = 1) => {
  wx.navigateBack({
    delta
  })
}

export const switchTab = url => {
  wx.switchTab({
    url
  })
}

// 隐藏系统tabbar setTabBarItem
export const hideTabBar = () => {
  wx.hideTabBar()
}

// 显示系统tabbar setTabBarItem
export const showTabBar = json => {
  wx.showTabBar(json)
}

// 设置tabbar style
export const setTabBarStyle = json => {
  wx.setTabBarStyle(json)
}

export const reLaunch = url => {
  wx.reLaunch({
    url
  })
}

export const startPullDownRefresh = () =>
  new Promise((resolve, reject) => {
    wx.startPullDownRefresh({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const stopPullDownRefresh = () =>
  new Promise((resolve, reject) => {
    wx.stopPullDownRefresh({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const checkSession = () =>
  new Promise((resolve, reject) => {
    wx.checkSession({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

// https://developers.weixin.qq.com/miniprogram/dev/api/api-react.html#wxshowtoastobject
export const showLoading = (data = {
  title: '加载中...'
}) => {
  const opts = typeof data === 'string' ? {
    title: data
  } : data
  wx.showLoading(opts)
}

export const hideLoading = () => {
  wx.hideLoading()
}

export const showToast = data => {
  let toast = {
    title: '',
    icon: 'none',
    duration: 2000,
    mask: true
  }
  // let toast = {}
  if (typeof data === 'string') {
    toast = {
      title: data,
      icon: 'none',
      duration: 2000,
      mask: true
    }
  } else {
    toast = {
      title: data,
      icon: 'none',
      duration: 2000,
      mask: true
    }
  }
  wx.showToast(toast)
}

export const getSetting = () =>
  new Promise((resolve, reject) => {
    wx.getSetting({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const authorize = scope =>
  new Promise((resolve, reject) => {
    wx.authorize({
      scope: scope,
      success () {
        resolve()
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const previewImage = (urls, current = '') => {
  wx.previewImage({
    current, // 当前显示图片的http链接
    urls // 需要预览的图片http链接列表
  })
}

export const makePhoneCall = tel => {
  wx.makePhoneCall({
    phoneNumber: tel // 电话号码
  })
}

// export const uploadFile = obj =>
//   new Promise((resolve, reject) => {
//     obj.url = uploadUrl + obj.url
//     wx.uploadFile({
//       ...obj,
//       success (res) {
//         console.log('uploadFile success', res)
//         resolve(res)
//       },
//       fail (e) {
//         console.log('uploadFile fail', e)
//         reject(e)
//       }
//     })
//   })

// export const downloadFile = obj =>
//   new Promise((resolve, reject) => {
//     const SessionId = getStorage(StorageKey.SessionId)
//     let header = {
//       'content-type': 'application/json; charset=utf-8',
//       'Authorization': 'Bearer' + ' ' + SessionId
//     }
//     obj.url = baseUrl + obj.url
//     wx.downloadFile({
//       ...obj,
//       header,
//       success (res) {
//         if (res.statusCode === 200) {
//           resolve(res.tempFilePath)
//         } else {
//           reject(new Error('文件下载失败！' + JSON.stringify(res)))
//         }
//       },
//       fail (e) {
//         reject(e)
//       }
//     })
//   })

// export const canvasToTempFilePath = obj =>
//   new Promise((resolve, reject) => {
//     wx.canvasToTempFilePath({
//       ...obj,
//       success (res) {
//         console.log('res.tempFilePath: ' + res.tempFilePath)
//         resolve(res.tempFilePath)
//       },
//       fail (e) {
//         console.log('canvasToTempFilePath error: ' + JSON.stringify(e))
//         reject(e)
//       }
//     })
//   })

export const saveImageToPhotosAlbum = filePath =>
  new Promise((resolve, reject) => {
    wx.saveImageToPhotosAlbum({
      filePath,
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const saveFile = tempFilePath =>
  new Promise((resolve, reject) => {
    wx.saveFile({
      tempFilePath,
      success (res) {
        resolve(res.savedFilePath)
      },
      fail (e) {
        console.log('saveFile', e)
        reject(e)
      }
    })
  })

export const saveVideoToPhotosAlbum = filePath =>
  new Promise((resolve, reject) => {
    wx.saveVideoToPhotosAlbum({
      filePath,
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const setClipboardData = text =>
  new Promise((resolve, reject) => {
    wx.setClipboardData({
      data: text,
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const showModal = data => {
  return new Promise((resolve, reject) => {
    wx.showModal({
      title: data.title || '温馨提示',
      content: data.content,
      showCancel: data.showCancel,
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })
}
// export const requestPayment = obj =>
//   new Promise((resolve, reject) => {
//     wx.requestPayment({
//       ...obj,
//       success (res) {
//         resolve(res.data)
//       },
//       fail (e) {
//         reject(e)
//       }
//     })
//   })
export const getImageInfo = src =>
  new Promise((resolve, reject) => {
    wx.getImageInfo({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })

export const getSystemInfo = src =>
  new Promise((resolve, reject) => {
    wx.getSystemInfo({
      success (res) {
        resolve(res)
      },
      fail (e) {
        reject(e)
      }
    })
  })
export default {
  getSystemInfo,
  getStorage,
  setStorage,
  getLocation,
  chooseLocation,
  removeStorage,
  clearStorage,
  wxLogin,
  chooseImage,
  showShareMenu,
  hideShareMenu,
  pageScrollTo,
  // getUserInfo,
  navigateTo,
  redirectTo,
  switchTab,
  navigateBack,
  startPullDownRefresh,
  stopPullDownRefresh,
  // uploadFile,
  checkSession,
  showToast,
  showLoading,
  hideLoading,
  authorize,
  previewImage,
  makePhoneCall,
  reLaunch,
  getSetting,
  // downloadFile,
  // canvasToTempFilePath,
  saveImageToPhotosAlbum,
  saveVideoToPhotosAlbum,
  hideTabBar,
  showTabBar,
  setTabBarStyle,
  openLocation,
  saveFile,
  showModal
  // requestPayment
}
