export const StorageKey = {
  SessionId: 'SESSION_ID',
  CustomerId: 'CUSTOMER_ID',
  LiteAppOpenID: 'LITE_APP_OPEN_ID',
  WxUnionID: 'WX_UNION_ID',
  WxOpenID: 'WX_OPEN_ID'
}

export default {
  StorageKey
}
