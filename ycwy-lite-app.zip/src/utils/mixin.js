import {
  showLoading,
  hideLoading,
  navigateTo,
  redirectTo,
  showToast,
  navigateBack,
  reLaunch,
  previewImage
} from './wx';

export default {
  computed: {
    customerId() {
      return this.$store.state.Customer.CustomerID;
    }
  },
  data() {
    return {
      ossUrl: 'https://myunonline-qiangban.oss-cn-hangzhou.aliyuncs.com/lite-app-static/images/',
      EInfo: { College: '', Degree: '', EndDate: '', Major: '', StartDate: '', Company: '', JobDesc: '', Position: '' }
    };
  },
  mounted() {
  },
  methods: {
    showLoading(data) {
      showLoading(data);
    },
    hideLoading() {
      hideLoading();
    },
    showToast(data) {
      showToast(data);
    },
    navigateTo(url) {
      navigateTo(url);
    },
    redirectTo(url) {
      redirectTo(url);
    },
    navigateBack(delta) {
      navigateBack(delta);
    },
    reLaunch(url) {
      reLaunch(url);
    },
    previewImage(urls, url) {
      previewImage(urls, url);
    },
    inputChange(event, key) {
      const arr = key.split('.'); // 'a.b.c'
      if (arr.length === 1) this[arr[0]] = event.mp.detail;
      else if (arr.length === 2) this[arr[0]][arr[1]] = event.mp.detail;
      else if (arr.length === 3) this[arr[0]][arr[1]][arr[2]] = event.mp.detail;
      else showToast('你是黑客么');
    }
  }
};
