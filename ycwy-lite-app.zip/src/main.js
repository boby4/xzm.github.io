import Vue from 'vue'
import App from './App'
import store from './store'
// import qs from 'qs';
import mixins from './utils/mixin'
import md5 from 'js-md5';

Vue.prototype.$md5 = md5;
Vue.config.productionTip = false
// Vue.prototype.$qs = qs
App.mpType = 'app'
Vue.prototype.$store = store
Vue.mixin(mixins)
const app = new Vue(App)
app.$mount()
// Vue.prototype.globalData = getApp().globalData
