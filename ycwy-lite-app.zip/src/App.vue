<script>
  import { getLiteAppConfig } from './api';
  import { StorageKey } from '@/utils/config';
  import { setStorage, getStorage } from '@/utils/wx';
export default {
  created () {
    // 调用API从本地缓存中获取数据
    /*
     * 平台 api 差异的处理方式:  api 方法统一挂载到 mpvue 名称空间, 平台判断通过 mpvuePlatform 特征字符串
     * 微信：mpvue === wx, mpvuePlatform === 'wx'
     * 头条：mpvue === tt, mpvuePlatform === 'tt'
     * 百度：mpvue === swan, mpvuePlatform === 'swan'
     * 支付宝(蚂蚁)：mpvue === my, mpvuePlatform === 'my'
     */

    let logs
    if (mpvuePlatform === 'my') {
      logs = mpvue.getStorageSync({key: 'logs'}).data || []
      logs.unshift(Date.now())
      mpvue.setStorageSync({
        key: 'logs',
        data: logs
      })
    } else {
      logs = mpvue.getStorageSync('logs') || []
      logs.unshift(Date.now())
      mpvue.setStorageSync('logs', logs)
    }
  },
  log () {
    console.log(`log at:${Date.now()}`)
  }
}
</script>

<style lang="less">
  @import '../static/less/theme.less';
  @import '../static/less/font.less';
 page{
    width:100%;
    overflow-x:hidden;
    background-color: #f8f8f8;
  }
.container {
  height: 100%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  padding: 200rpx 0;
  box-sizing: border-box;
}

 .bg-gray {
    background: @bgGray;
  }

  .bg-white {
    background: @white;
  }

  .bg-skyblue {
    background: #1fbdf9;
  }

  .container-fixed {
    position: fixed;
    height: 100%;
    width: 100%;
  }

  .container-absolute {
    position: absolute;
    max-height: 100%;
    overflow: hidden;
    top: 0;
    left: 0;
    width: 100%;
  }

  .container-relative {
    position: relative;
  }

  .text-center {
    text-align: center;
  }

  .text-right {
    text-align: right;
  }

  .text-left {
    text-align: left !important;
  }

  .pull-left {
    float: left;
  }

  .pull-right {
    float: right;
  }

  .ellipsis {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    word-wrap: normal;
  }

  .ellipsis--l2 {
    max-height: 40px;
    line-height: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
  }

  .ellipsis--l3 {
    max-height: 60px;
    line-height: 20px;
    overflow: hidden;
    text-overflow: ellipsis;
    display: -webkit-box;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
  }

  .clearfix {
    zoom: 1;
  }

  .clearfix::after {
    content: '';
    display: table;
    clear: both;
  }

  input {
    border: 0 none;
    box-sizing: border-box;
  }

  .divider {
    position: relative;
  }

  .divider>view {
    position: relative;
    z-index: 2;
    background: @white;
    padding: 0 30rpx;
    display: inline-block;
  }

  .divider:after {
    content: '';
    position: absolute;
    height: 1rpx;
    background: @borderColor;
    top: 50%;
    left: 0;
    width: 100%;
  }

  .flex-box,
  .flex-c-c {
    display: flex;
    align-items: center;
    justify-content: center;
  }

  .flex-box-normal,
  .flex-fs {
    display: flex;
    align-items: flex-start;
  }

  .flex-1 {
    flex: 1;
  }

  .flex-2 {
    flex: 2;
  }

  .flex {
    display: flex;
  }

  .flex-c-sb {
    display: flex;
    align-items: center;
    justify-content: space-between;
  }

  .flex-c {
    display: flex;
    align-items: center;
  }

  .flex-c-e {
    display: flex;
    align-items: center;
    justify-content: flex-end;
  }

  .text-0 {
    font-size: 0 !important;
  }

  .text-20 {
    font-size: 20rpx;
  }

  .text-22 {
    font-size: 22rpx;
  }

  .text-24 {
    font-size: 24rpx;
  }

  .text-25 {
    font-size: @tipsFontSize;
  }

  .text-26 {
    font-size: 26rpx;
  }

  .text-30 {
    font-size: @bodyFontSize;
  }

  .text-31 {
    font-size: 31rpx;
  }

  .text-28 {
    font-size: 28rpx;
  }

  .text-32 {
    font-size: @btnFontSize;
  }

  .text-34 {
    font-size: 34rpx;
  }

  .text-36 {
    font-size: 36rpx !important;
  }

  .text-42 {
    font-size: @titleFontSize  !important;
  }

  .text-40 {
    font-size: 40rpx !important;
  }

  .text-44 {
    font-size: 44rpx;
  }

  .text-46 {
    font-size: 46rpx !important;
  }

  .text-48 {
    font-size: 48rpx;
  }

  .text-70 {
    font-size: 70rpx;
  }

  .text-83 {
    font-size: 83rpx;
  }

  .text-gray {
    color: @gray;
  }

  .text-white {
    color: @white;
  }

  .text-orange {
    color: @primaryColor;
  }

  .text-black {
    color: @baseFont;
  }

  .text-blue {
    color: @blue;
  }

  .text-lightBlue {
    color: @lightBlue;
  }

  .text-red {
    color: @red  !important;
  }

  .text-red2 {
    color: #FF0015;
  }

  .text-yellow {
    color: @yellow;
  }

  .text-green {
    color: @green;
  }

  .text-brown {
    color: @brown;
  }

  .c1 {
    color: @c1;
  }

  .c2 {
    color: @c2;
  }

  .c3 {
    color: @c3;
  }

  .c8 {
    color: #888;
  }

  .text-bold {
    font-weight: bold;
  }

  .pad-0 {
    padding: 0 !important;
  }

  .pad-normal {
    padding: @sectionGutter @verticalGutter;
  }

  .pad-32 {
    padding: @verticalGutter;
  }

  .pad-36 {
    padding: 36rpx;
  }

  .pad-b-14 {
    padding-bottom: 14rpx;
  }

  .pad-b-20 {
    padding-bottom: 20rpx;
  }

  .pad-b-32 {
    padding-bottom: @verticalGutter;
  }

  .pad-b-42 {
    padding-bottom: 42rpx;
  }

  .pad-t-32 {
    padding-top: @verticalGutter;
  }

  .pad-t-64 {
    padding-top: 64rpx;
  }

  .pad-t-8 {
    padding-top: 8rpx;
  }

  .pad-r-8 {
    padding-right: 8rpx;
  }

  .pad-l-0 {
    padding-left: 0 !important;
  }

  .pad-l-8 {
    padding-left: 8rpx;
  }

  .pad-r-32 {
    padding-right: @verticalGutter;
  }

  .pad-t-0 {
    padding-top: 0;
  }

  .pad-t-16 {
    padding-top: 16rpx;
  }

  .pad-tb-10 {
    padding: 10rpx 0;
  }

  .pad-tb-26 {
    padding: 26rpx 0;
  }

  .pad-tb-30 {
    padding: 15rpx 0 20rpx;
  }

  .pad-tb-36 {
    padding: 36rpx 0;
  }

  .pad-tb-46 {
    padding: 46rpx 0;
  }

  .pad-tb-20 {
    padding: 20rpx 0;
  }

  .pad-tb-92 {
    padding: 92rpx 0 56rpx;
  }

  .pad-tb-110 {
    padding: 110rpx 0;
  }

  .pad-lr-28 {
    padding: 0 28rpx !important;
  }

  .pad-lr-32 {
    padding: 0 32rpx !important;
  }

  .pad-lr-36 {
    padding: 0 36rpx !important;
  }

  .pad-lr-48 {
    padding: 0 48rpx !important;
  }

  .mar-lr-auto {
    margin-right: auto;
    margin-left: auto;
  }

  .mar-t-15 {
    margin-top: 15rpx;
  }

  .mar-t-20 {
    margin-top: 20rpx;
  }

  .mar-t-36 {
    margin-top: 36rpx;
  }

  .mar-lf-23 {
    margin: 0 23rpx;
  }

  .mar-t-44 {
    margin-top: 44rpx;
  }

  .mar-r-100 {
    margin-right: 100rpx;
  }

  .mar-l-12 {
    margin-left: 12rpx;
  }

  .mar-l-16 {
    margin-left: 16rpx;
  }

  .mar-l-32 {
    margin-left: 32rpx;
  }

  .mar-r-16 {
    margin-right: 16rpx;
  }

  .mar-r-30 {
    margin-right: 30rpx;
  }

  .mar-tb-10 {
    margin: 10rpx 0;
  }

  .mar-t-10 {
    margin-top: 10rpx;
  }

  .mar-b-20 {
    margin-bottom: 20rpx;
  }

  .icon-mar-r {
    margin-right: 14rpx;
  }

  .icon-mar-l {
    margin-left: 14rpx;
  }

  .qy-border-b {
    border-bottom: 20rpx solid @bgGray;
  }

  .qy-border-0 {
    border-top: 0 !important;
  }

  .qy-border-b1 {
    border-bottom: 1rpx solid @borderColor;
  }

  .line-block-vm {
    vertical-align: middle;
    display: inline-block;
  }

  .line-vm {
    vertical-align: middle;
  }

  .border-radius-0 {
    border-radius: 0;
  }

  .avatar {
    display: inline-block;
    border-radius: 100%;
    overflow: hidden;
  }

  .avatar {
    border: 1rpx solid @borderColor;
    width: 116rpx;
    height: 116rpx;
  }

  .avatar image {
    height: 100%;
  }

  .circleImg {
    width: 143rpx;
    height: 143rpx;
    border-radius: 50%;
    overflow: hidden;
  }

  image {
    width: 100%;
  }

  .rectImg {
    width: 143rpx;
    height: 143rpx;
  }

  .split-line {
    height: 20rpx;
    background: @split-bg;
  }

  .overflow {
    overflow: hidden;
  }

  .qy-btn.van-button--primary {
    border-color: @lightBlue;
  }

  .qy-btn.van-button--primary.van-button--plain {
    color: @lightBlue;
  }

  .btn-red.btn {
    background: @btnRed;
  }

  .btn-orange.van-button--default {
    border-color: @btnOrange;
    color: @btnOrange;
  }

  .hidden {
    display: none;
  }

  .relative {
    position: relative;
  }

  .van-popup {
    border-radius: 8rpx;
  }

  .required::after {
    content: '*';
    color: #ff0000;
  }

  /**button 去除默认样式**/
  button {
    padding: 0;
    border-radius: 0;
    margin: 0;
    overflow: visible;
    font-size: inherit;
    line-height: 1;
    color: inherit;
    background: transparent;
  }

  button:after {
    border: 0 none;
  }

  .button-hover {
    background-color: transparent;
  }

  .btn {
    display: flex;
    height: 84rpx;
    font-size: 33rpx;
    color: #fff;
    align-items: center;
    justify-content: center;
  }

  .btn.fixed,
  .btn-round.fixed {
    position: fixed;
    right: 0;
    left: 0;
    bottom: 56rpx;
  }

  .btn.fixed-b,
  .btn-round.fixed-b {
    position: fixed;
    right: 0;
    bottom: 0;
    left: 0;
  }

  .btn-round:extend(.btn) {
    border-radius: 42rpx;
  }

  .bg-skyblue {
    background: #1fbdf9;
  }

  .btn-round-blue:extend(.btn-round) {
    border: 1rpx solid #1fbdf9;
    color: #1fbdf9;
  }

  .btn-round-orange:extend(.btn-round) {
    border: 1rpx solid #ff8400;
    color: #ff8400;
  }

  button.send-btn {
    display: flex;
    height: 60rpx;
    padding: 0 26rpx;
    margin-left: 26rpx;
    font-size: 28rpx;
    border: 1rpx solid #d7d7d7;
    white-space: nowrap;
    align-items: center;
  }

  button.send-btn.active {
    color: #fff;
    border-color: #22aeeb;
    background: #22aeeb;
  }

  /*******表单相关*********/
  // 十字获取图片
  .cross-picture {
    padding: 0 0 0 47rpx;
    border-top: 1rpx solid #ebedf0;
    overflow: hidden;
    line-height: 1;
  }

  .cross-picture .cross-picture-title {
    padding-top: 46rpx;
    font-size: 31rpx;
    color: #333;
  }

  .cross-picture .getImage {
    position: relative;
    float: left;
    width: 208rpx;
    height: 208rpx;
    border: 1rpx dashed #c0c0c0;
    margin-top: 35rpx;
    margin-right: 10rpx;
  }

  .cross-picture .getImage span {
    display: inline-block;
    padding: 5rpx 10rpx;
    border-radius: 50%;
    position: absolute;
    top: -20rpx;
    right: -15rpx;
    border: 2rpx solid #1fbdf9;
    background: #fff;
    font-weight: bold;
    color: #1fbdf9;
  }

  .cross-picture .getImage.add::before,
  .cross-picture .getImage.add::after {
    content: '';
    position: absolute;
    top: 50%;
    left: 50%;
    background: #c0c0c0;
    transform: translate(-50%, -50%);
  }

  .cross-picture .getImage::before {
    width: 5rpx;
    height: 65rpx;
  }

  .cross-picture .getImage::after {
    width: 65rpx;
    height: 5rpx;
  }

  /********写图标***********/
  .write-container {
    position: fixed;
    right: 33rpx;
    bottom: 119rpx;
    display: flex;
    width: 100rpx;
    height: 100rpx;
    background: rgba(31, 189, 249, 1);
    box-shadow: 0px 2rpx 5rpx 0px rgba(31, 249, 189, 0.35);
    border-radius: 50%;
    align-items: center;
    justify-content: center;
  }

  .wriet-icon {
    font-size: 48rpx;
    color: #fff;
  }

  /********tabbar***********/
  .tabbar {
    position: fixed;
    right: 0;
    bottom: 0;
    left: 0;
    height: 103rpx;
    font-size: 25rpx;
    line-height: 1;
    background: #fff;
    z-index: 10;
  }

  .tabbar-item {
    color: #7d7d7d;
  }

  .tabbar-item.active {
    color: #1fbdf9;
  }

  .tabbar-item .icon {
    margin-bottom: 8rpx;
    font-size: 40rpx;
    color: inherit;
  }

  .tabbar-item-text {
    margin-top: 8rpx;
  }

  /********popup***********/

  .popup {
    width: 600rpx;
    background: #fff;
    border-radius: 8rpx;
    overflow: hidden;
  }

  .popup-top {
    position: relative;
    height: 282rpx;
  }

  .popup-top-content {
    position: absolute;
    top: 50%;
    left: 50%;
    text-align: center;
    transform: translate(-50%, -50%);
  }

  .popup-top-content .icon {
    display: inline-block;
    margin-bottom: 37rpx;
    color: #f80000;
    margin-bottom: 37rpx;
  }

  .popup-top-content-text {
    font-size: 31rpx;
    color: #666;
  }

  .popup-bottom {
    height: 84rpx;
    border-top: 1rpx solid #e3e5e6;
    font-size: 33rpx;
  }

  .popup-bottom-left {
    color: #333;
    align-items: center;
    justify-content: center;
  }

  .popup-bottom-right {
    color: #1fbdf9;
    border-left: 1rpx solid #e3e5e6;
    align-items: center;
    justify-content: center;
  }

  /***van-cell-group border处理*****/
  .van-cell-container:not(:first-child) {
    border-top: 1px solid #ebedf0;
  }

  // 投诉样式
  .qy-tooltip {
    position: absolute;
    top: 64rpx;
    right: 20rpx;
    min-width: 210rpx;
  }

  .qy-tooltip-1 {
    min-width: 210rpx;
  }

  .qy-tooltip .content {
    padding: 30rpx 0;
    background: #2f2f2f;
    color: @white;
    border-radius: 6rpx;
  }

  .qy-tooltip .content>.line-block-vm {
    padding: 0 26rpx;
  }

  .qy-tooltip .content>.qy-border-r1 {
    border-right: 1rpx solid fade(@borderColor, 50%);
  }

  .qy-tooltip .content .down {
    transform: rotate(180deg);
  }

  .d-right-icon {
    display: flex;
    background: transparent;
    align-items: center;
    justify-content: center;
    z-index: 3;
  }

  .d-top .d-right .d-ad {
    display: flex;
    height: 30rpx;
    padding: 0 8rpx;
    border: 1rpx solid #dfdfdf;
    border-radius: 3rpx;
    margin: 0 10rpx 0 0;
    font-size: 88%;
    color: #999;
    background: #fff;
    align-items: center;
  }

  .qy-tooltip .arrow-up {
    position: absolute;
    width: 0;
    height: 0;
    top: -24rpx;
    right: 9rpx;
    border: 16rpx solid transparent;
    border-bottom-color: #2f2f2f;
  }

  /**圈优动态列表**/
  .d-imgs {
    height: auto !important;
  }

  .d-imgs::after {
    display: block;
    content: '';
    clear: both;
  }

  .d-imgs:empty {
    margin: 0 !important;
    height: 0 !important;
  }

  .d-imgs image:not(:only-child) {
    height: 215rpx !important;
    margin-bottom: 10rpx;
  }

  /* 搜索样式 */
  .search-box {
    border: 1rpx solid @borderColor;
    border-radius: 37rpx !important;
    height: 69rpx;
    line-height: 69rpx;
    padding-top: 7rpx;
    box-sizing: border-box;
  }
</style>
