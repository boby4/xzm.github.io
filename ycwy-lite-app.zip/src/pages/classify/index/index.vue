<template>
   <web-view :src="webviewUrl" @message="postMessage"/>
</template>

<script>
export default {
  data () {
    return {
      webviewUrl: '',
      params: '',
      hideWebview: false,
      payRes: '',
      orderId: '',
      allInfo: []
    }
  },
  onShow() {
    console.log(this.$root.$mp);
    this.payRes = this.$root.$mp.page.payRes
    this.orderId = this.$root.$mp.page.orderId
    if(this.payRes == 'success') {
      this.webviewUrl = `https://mini.yangche51.com/#/home?parmas=${this.params}&payRes=${this.payRes}&orderId=${this.orderId}`;
    }
  },
  onLoad(options) {
    wx.hideHomeButton({});
    this.params = this.$root.$mp.query.params;
    this.webviewUrl = `https://mini.yangche51.com/#/home?parmas=${this.params}`;
  },
  methods: {
    postMessage(options) {
      console.log('1111', options)
    }
  }
}
</script>

<style>
.counter-warp {
  text-align: center;
  margin-top: 100px;
}
</style>
