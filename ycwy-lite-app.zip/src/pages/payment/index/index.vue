<template>
  <div class="container">
    <div class="headCont">
      <div style="text-align:center;font-size:26rpx;padding-top:40rpx;">实际应付</div>
      <div style="text-align:center;font-size:48rpx;color:#ff0015;padding-top:20rpx;">{{payInfo.amount}}</div>
    </div>
    <div style="font-size:26rpx;padding-top:36rpx;color:#8c8b8b;margin-left:-600rpx;">付款方式</div>
    <van-radio-group :value="radio" @change="onChange" style="width:100%;top:280rpx;position:absolute;">
      <van-cell-group>
        <van-cell icon="wechat" title="微信支付" clickable data-name="1" @click="onClick">
          <van-radio checked-color="#07c160" slot="right-icon" name="1" />
        </van-cell>
      </van-cell-group>
    </van-radio-group>
    <van-button type="danger" round size="normal" block style="width:90%;padding-top:200rpx;" @click="wxPayment">确认支付</van-button>
  </div>
</template>
<script>
import { getWxPayInfo } from '@/api/payRequest';
export default {
  data () {
    return {
      radio: '1',
      openId: '',
      payInfo: {},
      payAmount: '',
      wxPayInfo: {},
      allInfo: null,
      pages: '',
      prevPage: ''
    }
  },
  onShow() {
    this.pages = getCurrentPages();
    this.prevPage = this.pages[ this.pages.length - 2 ];
  },
  async onLoad(options) {
    this.openId = this.$store.state.openId.openId;
    wx.hideHomeButton({
    });
    this.payInfo = options
    await this.getOpenId()
  },
  methods: {
    onChange(e) {
      this.radio = e.mp.detail
    },
    onClick(e) {
      const name = e.mp.currentTarget.dataset.name;
      this.radio = name;
    },
    async getOpenId() {
      this.payAmount = this.payInfo.amount.substr(1)
      console.log('sdjalksdsa', this.payAmount);
      const json = {
        hidOrderamount: this.payAmount,
        hidOrderIds: this.payInfo.orderId,
        hidOrderCode: this.payInfo.orderCode,
        hidPayPlat: 25,
        // oID: 'oUWfbwBArZVEWgEiUxXHJYCIXSHI'
        oID: this.openId
      }
      let res = await getWxPayInfo(json)
      this.wxPayInfo = res.replace('(', '').replace(')', '')
      this.allInfo = JSON.parse(this.wxPayInfo)
    },
    wxPayment() {
      wx.requestPayment({
          timeStamp: this.allInfo.timestamp,
          nonceStr: this.allInfo.noncestr,
          package: this.allInfo.package,
          signType: this.allInfo.signType,
          paySign: this.allInfo.sign,
          success: (res) => {
              wx.showToast({
                  title: '支付成功！',
                  icon: 'success',
                  duration: 2000,
              })  
              this.prevPage.payRes = 'success'
              this.prevPage.orderId = this.payInfo.orderId
              wx.navigateBack({
                delta: 1
              })
          }, fail: (res) => {
            console.log(res)
              wx.showToast({
                  title: "支付失败！",
                  icon: 'none',
                  duration: 1500
              })
              // this.prevPage.payRes = 'fail'
              // this.prevPage.orderId = this.payInfo.orderId
              // wx.navigateBack({
              //   delta: 1
              // })
          }
      })
    }
  }
}
</script>
<style>
    .container{
      width: 100%;
      height: 100%;
      background: #f8f8f8;
      position: relative;
      color: #282828;
    }
    .headCont {
      position: absolute;
      top: 20rpx;
      width: 100%;
      height: 200rpx;
      background: white;
    }
    .van-cell .van-cell__left-icon-wrap{
      color: #07c160;
    }
</style>
