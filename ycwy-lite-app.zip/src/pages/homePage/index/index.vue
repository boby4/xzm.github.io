<template>
  <div class="ioscontainer">
    <van-tabs type="card" swipeable="true" @change="onChange">
      <van-tab title="账号登录">
        <div class="logoPho text-center">
          <image src="/static/images/yangchelogo.png" style="width: 60px;"></image>
        </div>
        <div class="middle-z">
            <van-cell-group style="width:100%; margin:70rpx 0;">
              <van-field left-icon="contact" :value="account" placeholder="请输入账号/手机号码" @change="inputChange($event,'account')"/>
              <van-field left-icon="bag-o" type="password" :value="password" placeholder="请输入密码" @change="inputChange($event,'password')"/>
            </van-cell-group>
        </div>
        <div class="bangDing" @click="goJudge">同意并登录</div>
        <!-- <div class="registers">注册</div>
        <div class="register">忘记密码？</div> -->
      </van-tab>
      <van-tab title="验证登录">
        <div class="logoPho text-center">
          <image src="/static/images/yangchelogo.png" style="width: 60px;"></image>
        </div>
        <div class="middle-z">
            <van-cell-group style="width:100%; margin:70rpx 0;">
              <van-field  :value="userPhone" left-icon="contact" center clearable placeholder="请输入手机号码" use-button-slot  @change="inputChange($event,'userPhone')">
                <van-button slot="button" size="small" type="primary" @click="getAuthCode()" v-if="sendAuthCode === true">获取验证码</van-button>
                <van-button color="#cdcdcd" disabled plain slot="button" type="default" size="small" v-if="sendAuthCode === false">倒计时{{authtime}}秒</van-button>
              </van-field>
              <van-field left-icon="bag-o" type="number" :value="statusCode" placeholder="请输入验证码" @change="inputChange($event,'statusCode')"/>
            </van-cell-group>
        </div>
        <div class="bangDing" @click="goGetUserLogin">同意并登录</div>
        <div class="register">新用户登录即完成注册，代表同意《养车无忧用户协议》</div>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
  import { CustomerPaswdLogin, CustomerVerifyCode, CustomerUserLogin } from '@/api/my';
  import { BindOpenId, getBindInfo } from '@/api/index';
  import { StorageKey } from '@/utils/config';
  import { setStorage, wxLogin } from '@/utils/wx';
  export default {
    data() {
      return {
        loading: false,
        sendAuthCode: true,
        authtime: 0,
        userId: null,
        ticket: '',
        appTicket: '',
        userPhone: '',
        account: '',
        password: '',
        jsCode: '',
        access: ''
      };
    },
    onLoad() {
    },
    onShow() {
      this.Init();
      wx.hideHomeButton({});
    },
    methods: {
      async Init() {
        await this.getBindInfo()
      },
      onChange(e) {
        // this.account = '';
        this.password = '';
        this.userPhone = '';
        this.statusCode = '';
      },
      async getBindInfo() {
        const res = await wxLogin();
        let jsCode = res.code;
        let json = {
          jsCode: jsCode
        }
        let resd = await getBindInfo(json)
        if(resd.result !== null) {
          this.appTicket = resd.result.appTicket;
          this.account = resd.result.mobile;
          this.ticket = resd.result.ticket;
          this.userId = resd.result.userId;
          let params = {
            userId: this.userId,
            ticket: this.ticket,
            appTicket: this.appTicket
          }
          this.$store.commit('openId', {
            openId: resd.result.openId
          })
          wx.reLaunch({
              url: `/pages/classify/index/main?params=${JSON.stringify(params)}`
          })
        }
      },
      async bindLiteAppId() {
        let codeInfo = await wxLogin();
        let jsCode = codeInfo.code;
        const data = {
          appTicket: this.appTicket,
          mobile: this.account,
          jsCode: jsCode,
          ticket: this.ticket,
          userId: this.userId
        }
        let res = await BindOpenId(data)
        if(res.status.code == 200) {
          this.showToast('微信绑定成功')
          const params = {
            userId: this.userId,
            ticket: this.ticket,
            appTicket: this.appTicket
          }
          this.$store.commit('openId', {
            openId: res.result.openId
          })
          wx.reLaunch({
              url: `/pages/classify/index/main?params=${JSON.stringify(params)}`
          })
        } else {
          this.showToast('微信绑定失败')
        }
      },
      async goJudge() {
        let data = {
            loginName: this.account,
            loginPaswd: this.$md5(this.password)
        }
        let res = await CustomerPaswdLogin(data)
        if(res.Body.ResultCode == 0) {
          this.userId = res.Body.UserId;
          this.ticket = res.Body.ticket;
          this.appTicket = res.Body.appTicket;
          await this.bindLiteAppId();
        } else {
          this.showToast(res.Body.Message);
        }
      },
      async getAuthCode() {
        if(this.userPhone == '') {
          this.showToast('请输入手机号')
        } else {
          await this.geVerifyCode()
          this.sendAuthCode = false;
          this.authtime = 60;
          var authtimetimer = setInterval(() => {
            this.authtime--;
            if (this.authtime <= 0) {
              this.sendAuthCode = true;
              clearInterval(authtimetimer);
            }
          }, 1000);
        }
      },
      async geVerifyCode() {
        const data = {
            Mobile: this.userPhone,
            Email: '',
            VerifyType: 4,
            ActivityNo: 'A10004',
            Mode: 0
          }
          let res = await CustomerVerifyCode(data)
          this.showToast(res.Body.Message);
      },
      async goGetUserLogin() {
        if(this.userPhone == '') {
          this.showToast('请输入手机号')
        } else if(this.statusCode == '') {
          this.showToast('请输入验证码')
        } else {
          const data = {
            Mobile: this.userPhone,
            InviterUserId: 0,
            VerifyCode: this.statusCode
          }
          let res = await CustomerUserLogin(data)
          this.userId = res.Body.UserId;
          this.ticket = res.Body.ticket;
          this.appTicket = res.Body.appTicket;
          await this.bindLiteAppId();
        }
      }
    }
  };
</script>

<style>

  page{
    width:100%;
    overflow-x:hidden;
    color:#282828;
    /* background: #f0f0f0; */
  }
  .logoPho image{
    width: 300rpx;
    height: 162rpx;
    margin-top: 100rpx;
  }
  .logoPho p{
    font-size: 28rpx;
    font-weight: bold;
    margin-top: 20rpx;
  }

  .middle-z {
    display: flex;
    flex-wrap: wrap;
    padding: 0 30rpx;
  }
  .auth_text{
    font-size: 26rpx;
    color: #cdcdcd;
    width: 178rpx;
    position: relative;
    height: 40rpx;
    line-height: 40rpx;
    text-align: center;
    border: 2rpx solid #cdcdcd;
    border-radius: 25rpx;
    left: 446rpx;
    bottom: 138rpx;
  }
  ._van-button .van-button--primary{
    background-color: rgba(255, 0, 21, 1);
    border: 1px solid rgba(255, 0, 21, 1);
    border-radius: 30rpx;
  }

 .bangDing{
    text-align: center;
    line-height: 88rpx;
    font-size: 36rpx;
    border-radius: 47rpx;
    background: #ff0015;
    color: white;
    margin: 0 auto;
    width:550rpx;
    height: 88rpx;
  }
  .registers{
    position: absolute;
    text-align: left;
    font-size: 22rpx;
    margin: 0 auto;
    margin-left: 80rpx;
    margin-top: 44rpx;
  }
  .register {
    text-align: right;
    font-size: 22rpx;
    margin: 0 auto;
    margin-top: 44rpx;
    width:550rpx;
  }
</style>