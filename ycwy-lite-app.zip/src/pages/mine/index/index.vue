<template>
   <web-view v-if="webviewUrl" :src="webviewUrl" @message="postMessage"/>
</template>

<script>
export default {
  data () {
    return {
      webviewUrl: 'https://mini.yangche51.com/#/home',
      params: ''
    }
  },
  onLoad(options) {
    console.log('options', options)
    this.objId = options.id;
    console.log('objid', this.objId)
  },
  onShow() {
    wx.hideHomeButton({
    });
    this.params = this.$root.$mp.query.params;
  },
  methods: {
    postMessage(options) {
      wx.navigateBack({
        delta: 1
      })
      console.log('1111', options)
    }
  }
}
</script>

<style>
.counter-warp {
  text-align: center;
  margin-top: 100px;
}
</style>
