// https://vuex.vuejs.org/zh-cn/intro.html
// make sure to call Vue.use(Vuex) if using a module system
import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    Customer: {
      Mobile: ''
    },
    openId: {},
    // CustomerId: 0,
    UserSysNo: 0,
    gobal: {},
    InvitationCode: 'quanyou',
    ShareCustomerID: '',
    hasLogin: 0,
    SessionId: '',
    AccessToken: '',
    authUserInfo: undefined,
    customerinfo: [],
    updateskip: '',
    // 用户兴趣爱好id
    CustomerHobbies: [],
    // 分享状态
    Contact: 0, // 分享进入 1，用户自主进入 0
    // 创建动态
    CircleID: [],
    TagList: [],
    // 动态发表-所属圈子ID
    CircleList: '',
    // 省市区
    pcdList: [],
    // 创建圈子
    CircleCateName: [],
    CircleCateID: [],
    // 工作经历，教育经历
    ExpressInfo: { College: '', Degree: '', EndDate: '', Major: '', StartDate: '', Company: '', JobDesc: '', Position: '' },
    // 职位分类页
    pageTwo: [],
    pageThree: [],
    WorkList: {}
  },
  mutations: {
    openId(state, value) {
      state.openId = value
    },
    updatecardinfo: (state, data) => {
      state.Customer.HomeTown = data.HomeTown;
      state.Customer.HomeTownCode = data.HomeTownCode;
      state.Customer.Location = data.Location;
      state.Customer.LocationCode = data.LocationCode;
    },
    updateauthUserInfo: (state, data) => {
      state.authUserInfo = data;
    },
    updateCustomer: (state, data) => {
      state.Customer = data;
    },
    updateShareId: (state, data) => {
      state.PersonSysNo = data.PersonSysNo;
      state.UserSysNo = data.UserSysNo;
    },
    updateInvitationCode: (state, data) => {
      state.InvitationCode = data;
    },
    updateLoginState: (state, data) => {
      state.hasLogin = data;
    },
    updateSessionId: (state, data) => {
      state.SessionId = data;
    },
    updateAccessToken: (state, data) => {
      state.AccessToken = data;
    },
    updateShareCustomerID: (state, data) => {
      state.ShareCustomerID = data;
    },
    updateskip: (state, data) => {
      state.updateskip = data;
    },
    // 分享状态
    updateContact: (state, data) => {
      state.Contact = data;
    },
    // 发布动态
    updateTagList: (state, data) => {
      state.TagList = data;
    },
    updateCircleList: (state, data) => {
      state.CircleList = data;
    },
    updatepcilist: (state, data) => {
      state.pcdList = data;
    },
    updatetTopicID: (state, data) => {
      state.CircleID = data;
    },
    updateclearDynamic: (state, data) => {
      state.CircleID = [];
      state.TagList.acitvename = [];
      state.TagList.activelist = [];
      state.CircleList = [];
    },
    // 创建圈子
    updateCircleCateName: (state, data) => {
      state.CircleCateName = data;
    },
    updateCircleCateID: (state, data) => {
      state.CircleCateID = data;
    },
    updateCustomerHobbies: (state, data) => {
      state.CustomerHobbies = data;
    },
    // 工作经历，教育经历
    updateExpressInfo: (state, data) => {
      state.ExpressInfo = data;
    },
    updatepageTwo: (state, data) => {
      state.pageTwo = data;
    },
    updatepageThree: (state, data) => {
      state.pageThree = data;
    },
    updateWorkList: (state, data) => {
      state.WorkList = data;
    }
  },
  actions: {}
});

export default store;
