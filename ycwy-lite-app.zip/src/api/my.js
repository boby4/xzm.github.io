import request from './https'

// 获取用户车型列表
export function getUserCarTypeList (params) {
  return request({
    url: '/6_1/car/picker/getAutoSeriesList_1_0.ashx',
    method: 'post',
    params: params
  })
}
// 登录获取ticket
export function CustomerPaswdLogin (params) {
  return request({
    url: '/customer/Goldmine/PaswdLogin',
    method: 'post',
    params: params
  })
}
// 获取验证码
export function CustomerVerifyCode (params) {
  return request({
    url: '/customer/VerifyCode/SendVerifyCode',
    method: 'post',
    params: params
  })
}
// 验证码登录
export function CustomerUserLogin (params) {
  return request({
    url: '/customer/Goldmine/UserLogin',
    method: 'post',
    params: params
  })
}