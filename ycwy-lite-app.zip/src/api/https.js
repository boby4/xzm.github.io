// import { getStorage } from '@/utils/wx'
// import { StorageKey } from '@/utils/config'
// import qs from 'qs'

const config = require('./config')

export default ({ url, params, method }) =>
  new Promise(async (resolve, reject) => {
    // const SessionId = getStorage(StorageKey.SessionId)
    let header = {
      'content-type': 'application/x-www-form-urlencoded; charset=UTF-8'
      // 'Authorization': 'Bearer' + ' ' + SessionId
    }
    // let data = method === 'get' ? params : qs.stringify(params)
    const dataValue = {
      Header: {
        SourceType: 1,
        UserPermit: "",
        SignCode: "5a2f40a07cf128b88f5e8319d57eda7a",
        UserTicket: "",
        AllowOriginUrl: "",
        ExpandInfo: "",
        AutoInfo: ""
      },
      Body: JSON.stringify(params)
    };
    let bodyData = {
      data: JSON.stringify(dataValue)
    };
    wx.request({
      url: `${config.baseUrl}${url}`,
      data: bodyData,
      header,
      method: method,
      success (res) {
        let resData = res.data
        resolve(resData)
        // if (resData.status.code === 200) {
        //   resolve(resData)
        // } else {
        //   resolve(resData)
        //   reject(new Error(resData.status.msg))
        // }
      },
      fail (e) {
        console.error(`wx.request error: ${JSON.stringify(e)}`)
        reject(new Error('哎呀，您的网络开小差了，请稍后再试！'))
      }
    })
  })