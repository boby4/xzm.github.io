import request from './miniRequest'
// import http from './https';

// 绑定小程序id 
export function BindOpenId (params) {
  return request({
    url: '/Auth/BindOpenId',
    method: 'post',
    params: params
  })
}
// 获取绑定记录
export function getBindInfo (params) {
  return request({
    url: `/Auth/BindOpenId`,
    method: 'get',
    params: params
  })
}