// import { getStorage } from '@/utils/wx'
// import { StorageKey } from '@/utils/config'

const config = require('./config')

export default ({ url, params, method, header }) =>
  new Promise(async (resolve, reject) => {
    // const SessionId = getStorage(StorageKey.SessionId)
    if(method == 'post') {
      header = {
        'content-type': 'application/json'
        // 'Authorization': 'Bearer' + ' ' + SessionId
      }
    } else {
      header = {
        'content-type': 'application/x-www-form-urlencoded'
        // 'Authorization': 'Bearer' + ' ' + SessionId
      }
    }
    wx.request({
      url: `${config.miniBaseUrl}${url}`,
      data: params,
      header,
      method: method,
      success (res) {
        let resData = res.data
        resolve(resData)
      },
      fail (e) {
        console.error(`wx.request error: ${JSON.stringify(e)}`)
        reject(new Error('哎呀，您的网络开小差了，请稍后再试！'))
      }
    })
  })