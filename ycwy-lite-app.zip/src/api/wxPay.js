const config = require('./config')

export default ({ url, params, method, header }) =>
  new Promise(async (resolve, reject) => {
    if(method == 'post') {
      header = {
        'content-type': 'application/json'
      }
    } else {
      header = {
        'content-type': 'application/x-www-form-urlencoded'
      }
    }
    wx.request({
      url: `${config.payUrl}${url}`,
      data: params,
      header,
      method: method,
      success (res) {
        let resData = res.data
        resolve(resData)
      },
      fail (e) {
        console.error(`wx.request error: ${JSON.stringify(e)}`)
        reject(new Error('哎呀，您的网络开小差了，请稍后再试！'))
      }
    })
  })