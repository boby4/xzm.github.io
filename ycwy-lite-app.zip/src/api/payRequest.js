import request from './wxPay'

// 获取用户车型列表
export function getWxPayInfo (params) {
  return request({
    url: '/wapPayment.ashx',
    method: 'get',
    params: params
  })
}