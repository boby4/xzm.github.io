module.exports = {
  // baseUrl: 'https://qy-api.myun.info', // 正式
  baseUrl: 'https://mm.yangche51.com',
  payUrl: 'https://pay.yangche51.com',
  miniBaseUrl: 'https://miniapi.yangche51.com',
  uploadUrl: 'https://thirdauthorization.yangche51.com', // 正式
  bizCompanyCode: 29018,
  companyCode: 29018
}