import request from './https'

// 获取字典
export function getDictionary (params) {
  return request({
    url: '/api/basic/getDictionary',
    method: 'post',
    params: params
  })
}
