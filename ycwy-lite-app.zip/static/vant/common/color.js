export var RED = '#4976d3';
export var BLUE = '#1989fa';
export var GREEN = '#07c160';
